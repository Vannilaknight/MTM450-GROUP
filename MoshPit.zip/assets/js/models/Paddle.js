var Paddle = function(display){
    this.paddleDisplay = display;
    this.speed = 5;
    this.controller;
    this.xCenter = 0;
    this.yCenter = 0;
};