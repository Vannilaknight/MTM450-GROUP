var Board = function(display){
    this.boardDisplay = display;
};