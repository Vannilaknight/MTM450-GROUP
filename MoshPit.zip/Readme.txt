No power ups yet
controlls are
p1: left and right arrow keys
p2: A and S keys
p3: V and B keys
p4: K and L keys
p5: < and > keys
p6: Z and X keys
p7: G and H keys
p8: I and O keys